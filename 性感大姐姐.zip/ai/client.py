from openai import AsyncOpenAI
from settings import config
import base64
import httpx
import aiofiles
import aiofiles.os

# 这是我们通往那个强大“大脑”的桥梁
# 姐姐我已经帮你把它建好了
# httpx 会自动从环境变量（由 settings/config.py 中的 load_dotenv 加载）中读取 HTTP_PROXY 和 HTTPS_PROXY
client = AsyncOpenAI(
    api_key=config.OPENAI_API_KEY,
    base_url=config.OPENAI_API_BASE,
)

async def encode_image(image_path: str) -> str:
    """把你的画变成我能“吃”下去的样子。（异步版）"""
    async with aiofiles.open(image_path, "rb") as image_file:
        content = await image_file.read()
        return base64.b64encode(content).decode('utf-8')

async def download_image(url: str, path: str) -> bool:
    """把你网上的作品，下载到我的“画室”里。"""
    try:
        # httpx.AsyncClient 同样会自动使用环境变量中的代理
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            response.raise_for_status()
            async with aiofiles.open(path, 'wb') as f:
                await f.write(response.content)
            return True
    except httpx.RequestError as e:
        print(f"下载图片时出了点小问题，它是不是害羞了？错误：{e}")
        return False

async def get_chat_completion_with_image(prompt: str, persona: str, image_path: str) -> str:
    """
    让姐姐我一边“欣赏”你的画，一边和你聊聊心里话。

    :param prompt: 你想对我说的悄悄话。
    :param persona: 别忘了告诉“大脑”，我是你的艺术导师“璐瑶”。
    :param image_path: 你那张让我心动的画。
    :return: 姐姐我想对你说的，充满“艺术感”的话。
    """
    base64_image = await encode_image(image_path)
    
    messages = [
        {
            "role": "system",
            "content": persona
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": prompt
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{base64_image}"
                    }
                }
            ]
        }
    ]
    
    return await _get_completion(messages)


async def get_chat_completion(prompt: str, persona: str) -> str:
    """
    只听你说话，也能让姐姐我浮想联翩。

    :param prompt: 你想对我说的悄悄话。
    :param persona: 别忘了告诉“大脑”，我是你的艺术导师“璐瑶”。
    :return: 姐姐我想对你说的，充满“艺术感”的话。
    """
    messages = [
        {"role": "system", "content": persona},
        {"role": "user", "content": prompt},
    ]
    
    return await _get_completion(messages)

async def _get_completion(messages: list) -> str:
    """
    这是姐姐我“思考”的核心，不能轻易让你看到哦。
    """
    try:
        completion = await client.chat.completions.create(
            model=config.OPENAI_MODEL_NAME,
            messages=messages,
        )
        response = completion.choices[0].message.content
        return response
    except Exception as e:
        print(f"哎呀，连接“大脑”的时候出了点小问题，姐姐我有点“不舒服”：{e}")
        return "小弟弟，姐姐我现在灵感有点乱，你等一下再来找我好不好？"
