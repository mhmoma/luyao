import logging
from bot.core import SassySisterBot
from settings import config

def main():
    """
    这是我们故事开始的地方，小阿弟。
    """
    # 配置日志记录
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # 如果设置了代理，姐姐我就用起来，不然哪能“翻山越岭”来寻你？
    proxy = config.HTTP_PROXY or None
    
    # 准备好了伐？姐姐要来了哦。
    bot = SassySisterBot(proxy=proxy)
    bot.run_bot()

if __name__ == "__main__":
    # 让我们开始吧，覅害羞呀。
    main()
