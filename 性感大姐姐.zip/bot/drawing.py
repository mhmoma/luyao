import discord
import aiohttp
import asyncio
import base64
import io
import logging
from discord.ext import commands
from discord import app_commands
from settings.config import IDLECLOUD_API_KEY, API_BASE_URL, HTTP_PROXY

# 请求头用于认证和发送 JSON 数据
HEADERS = {
    "Authorization": f"Bearer {IDLECLOUD_API_KEY}",
    "Content-Type": "application/json"
}

class Drawing(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.session = aiohttp.ClientSession(headers=HEADERS)
        self.proxy = HTTP_PROXY

    async def cog_unload(self):
        # 在 Cog 卸载时关闭 aiohttp session
        await self.session.close()

    async def submit_generation_task(self, prompt: str, negative_prompt: str = "") -> tuple[str, str | None]:
        """提交任务，只负责获取 job_id。"""
        payload = {
            "model": "nai-diffusion-3",
            "positivePrompt": prompt,
            "negativePrompt": negative_prompt,
            "width": 512, "height": 768, "steps": 28, "scale": 5.5,
            "sampler": "k_euler", "qualityToggle": True,
        }
        try:
            async with self.session.post(f"{API_BASE_URL}/generate_image", json=payload, proxy=self.proxy) as response:
                # 显式处理非 200 状态码
                if response.status != 200:
                    try:
                        data = await response.json()
                        error_msg = data.get("message") or f"API错误: HTTP {response.status}"
                    except:
                        error_msg = f"API错误: HTTP {response.status}, 无法解析响应。"
                    return error_msg, None
                
                data = await response.json()
                job_id = data.get("job_id")
                if not job_id:
                    return "API响应成功但未返回job_id", None
                return "job_submitted", job_id
        except Exception as e:
            return f"网络或未知错误: {e}", None

    async def poll_result_task(self, job_id: str) -> tuple[str, str | None]:
        """轮询结果。"""
        max_retries = 30
        logging.info(f"开始轮询 Job ID: {job_id}")
        for i in range(max_retries):
            await asyncio.sleep(5)
            logging.info(f"正在进行第 {i+1}/{max_retries} 次轮询 for Job ID: {job_id}")
            try:
                async with self.session.get(f"{API_BASE_URL}/get_result/{job_id}", proxy=self.proxy) as result_response:
                    if result_response.status != 200:
                        logging.warning(f"轮询 Job ID {job_id} 时收到非 200 状态码: {result_response.status}")
                        # 任何 4xx 错误都表示客户端有问题，是无法通过重试解决的，应立即停止
                        if 400 <= result_response.status < 500:
                            error_reason = f"API返回客户端错误 (状态码: {result_response.status})。这可能是由于请求参数错误、认证失败或资源不存在等原因造成的。"
                            try:
                                # 尝试解析 API 返回的具体错误信息
                                error_data = await result_response.json()
                                error_reason += f" API消息: {error_data.get('message', '无')}"
                            except Exception:
                                pass # 解析失败也没关系
                            return error_reason, None
                        continue # 对于 5xx 服务器错误，我们假设是临时的，继续尝试

                    result_data = await result_response.json()
                    logging.info(f"轮询 Job ID {job_id} 收到 API 响应: {result_data}")
                    status = result_data.get("status")

                    if status == "completed":
                        logging.info(f"Job ID {job_id} 已完成。")
                        image_b64 = result_data.get("image_base64")
                        return "completed", image_b64 if image_b64 else "任务完成但未返回图片数据。"
                    elif status == "failed":
                        error_msg = f"任务生成失败: {result_data.get('error', '未知错误')}"
                        logging.error(f"Job ID {job_id} 失败: {error_msg}")
                        return error_msg, None
                    else:
                        logging.info(f"Job ID {job_id} 当前状态: {status}，继续轮询...")
            except Exception as e:
                logging.error(f"轮询 Job ID {job_id} 时发生严重错误: {e}", exc_info=True)
                continue
        
        logging.warning(f"Job ID {job_id} 轮询超时。")
        return "超时失败：任务在预期时间内未完成。", None

    @app_commands.command(name="imagine", description="使用 IDLECLOUD API 生成图像")
    @app_commands.describe(
        prompt="你希望在图像中看到的内容",
        negative_prompt="你不希望在图像中看到的内容"
    )
    async def imagine_command(self, interaction: discord.Interaction, prompt: str, negative_prompt: str = ""):
        # 立即 defer 以告知 Discord 我们将稍后回应。
        # 这是处理耗时任务的标准做法。如果此步骤失败并出现“Unknown Interaction”错误，
        # 这几乎总是意味着机器人的事件循环被其他地方的同步代码阻塞了超过 3 秒。
        # 此重构改进了命令的流程，但可能无法解决外部阻塞问题。
        try:
            await interaction.response.defer(thinking=True)
        except discord.errors.NotFound:
            print("CRITICAL: 'Unknown Interaction' error on defer. The event loop is likely blocked by synchronous code elsewhere.")
            # 无法恢复，交互已失效，所以我们只能记录并返回
            return

        # 1. 提交任务
        submit_status, job_id = await self.submit_generation_task(prompt, negative_prompt)

        if submit_status != "job_submitted":
            # 提交失败 (job_id 实际上是错误信息)
            await interaction.edit_original_response(content=f"❌ **任务提交失败。**\n原因: `{job_id}`")
            return

        # 2. 任务提交成功，可以更新消息，让用户知道我们正在处理
        await interaction.edit_original_response(content=f"✅ 任务已提交 (Job ID: `{job_id}`)… 正在排队生成中，请稍候。")
        
        # 3. 轮询获取结果
        status, result_content = await self.poll_result_task(job_id)

        # 4. 处理结果
        if status == "completed" and result_content:
            try:
                image_data = base64.b64decode(result_content)
                image_file = discord.File(io.BytesIO(image_data), filename="generated_image.png")

                # 清空 content 并发送文件
                await interaction.edit_original_response(
                    content=f"✨ **生成完成!**\n**Prompt:** `{prompt}`",
                    attachments=[image_file]
                )
            except Exception as e:
                await interaction.edit_original_response(content=f"❌ **图像处理失败。**\n原因: `解码或发送文件时出错: {e}`")
        else:
            # 发送失败或超时消息 (status 在这里是错误信息)
            await interaction.edit_original_response(content=f"❌ **图像生成失败。**\n原因: `{status}`")


async def setup(bot: commands.Bot):
    await bot.add_cog(Drawing(bot))
    print("Drawing Cog loaded.")
