import os
from dotenv import load_dotenv

load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
HTTP_PROXY = os.getenv("HTTP_PROXY")
HTTPS_PROXY = os.getenv("HTTPS_PROXY")

# OpenAI-Compatible API Settings
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL_NAME = os.getenv("OPENAI_MODEL_NAME")

# Welcome message channel IDs
WELCOME_CHANNEL_IDS = os.getenv("WELCOME_CHANNEL_IDS")

# Allowed channel IDs for the bot to speak in
ALLOWED_CHANNEL_IDS = os.getenv("ALLOWED_CHANNEL_IDS")

# Admin user ID
ADMIN_USER_ID = os.getenv("ADMIN_USER_ID")

# Channel IDs for automatic cleanup
CLEANUP_CHANNEL_IDS = os.getenv("CLEANUP_CHANNEL_IDS")

# IDLECLOUD API Settings
API_BASE_URL = "https://image.idlecloud.cc/api"
IDLECLOUD_API_KEY = os.getenv("IDLECLOUD_API_KEY")
